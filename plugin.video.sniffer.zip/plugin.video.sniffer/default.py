import html
import importlib.util
import json
import os
import re
import socket
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.error import HTTPError, URLError
from urllib.parse import parse_qs, quote, urlencode, urljoin, urlparse
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else -1
BASE_URL = sys.argv[0] if sys.argv else ""
ADDON_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
LIB_DIR = os.path.join(ADDON_DIR, "resources", "lib")
YTDLP_ZIP = os.path.join(LIB_DIR, "yt_dlp.zip")
RESULTS_FILE = os.path.join(PROFILE_DIR, "recent_results.json")
DIAGNOSTICS_FILE = os.path.join(PROFILE_DIR, "diagnostics.json")
SERVER_STATE_FILE = os.path.join(PROFILE_DIR, "server_state.json")
MEDIA_RE = re.compile(r"(?P<url>(?:https?:)?//[^\s'\"<>]+?\.(?:m3u8|mp4|webm|mov)(?:\?[^\s'\"<>]*)?)", re.I)
ATTR_MEDIA_RE = re.compile(r"(?:src|href|file|url)\s*[:=]\s*['\"](?P<url>[^'\"]+?\.(?:m3u8|mp4|webm|mov)(?:\?[^'\"]*)?)['\"]", re.I)
RUNNING_SERVER = None

for library_path in (YTDLP_ZIP, LIB_DIR):
    if os.path.exists(library_path) and library_path not in sys.path:
        sys.path.insert(0, library_path)


def decode_form(body):
    fields = parse_qs(body.decode("utf-8", "replace"), keep_blank_values=True)
    return {key: values[0].strip() for key, values in fields.items()}


def html_page(title, body):
    return ("<!doctype html><html><head><meta charset='utf-8'>"
            "<meta name='viewport' content='width=device-width,initial-scale=1'>"
            "<title>{0}</title><style>body{{font-family:sans-serif;margin:24px;line-height:1.5}}"
            "input,textarea,button{{box-sizing:border-box;width:100%;padding:10px;margin:8px 0;font-size:16px}}"
            "textarea{{height:160px}}button{{background:#1677ff;color:white;border:0;border-radius:4px}}</style></head>"
            "<body><h2>{0}</h2>{1}</body></html>").format(html.escape(title), body)


class PhoneInputHandler(BaseHTTPRequestHandler):
    server_version = "KodiVideoSniffer/1.0"

    def log_message(self, fmt, *args):
        xbmc.log("[%s] %s" % (ADDON_ID, fmt % args), xbmc.LOGDEBUG)

    def send_html(self, status, title, body):
        payload = html_page(title, body).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        current = html.escape(current_url() or "")
        body = """
        <p>在这里输入视频网页地址。遇到人机验证时，先用外部浏览器完成验证，再把最终网页地址或已复制的视频直链提交回来。</p>
        <form method="post" action="/submit">
          <label>网页地址</label>
          <input name="target_url" value="{current}" placeholder="https://example.com/video">
          <label>视频直链，可选</label>
          <input name="media_url" placeholder="https://.../index.m3u8 或 .mp4">
          <label>页面源码，可选</label>
          <textarea name="page_source" placeholder="如果浏览器能复制验证后的页面源码，可粘贴到这里"></textarea>
          <button type="submit">提交给 KODI 插件</button>
        </form>
        <p>提交后回到 KODI，打开“查看最近嗅探结果”或“嗅探当前网页”。</p>
        """.format(current=current)
        self.send_html(200, "KODI 视频嗅探输入", body)

    def do_POST(self):
        if self.path != "/submit":
            self.send_html(404, "未找到", "<p>路径不存在。</p>")
            return
        length = int(self.headers.get("Content-Length", "0") or 0)
        form = decode_form(self.rfile.read(length))
        target_url = form.get("target_url", "")
        media_url = form.get("media_url", "")
        page_source = form.get("page_source", "")
        if target_url:
            save_current_url(target_url)
        if media_url:
            item = {"url": media_url, "label": "手机提交的视频直链 (%s)" % media_type(media_url), "title": "手机提交的视频直链", "quality": quality_from_url(media_url), "type": media_type(media_url), "thumb": ""}
            write_json(RESULTS_FILE, {"source_url": target_url, "final_url": target_url, "updated_at": int(time.time()), "items": [item]})
        elif page_source:
            source_url = target_url or "http://local-submitted-page/"
            title, thumb = extract_metadata(source_url, page_source)
            items = expand_m3u8_results(extract_media(source_url, page_source, title, thumb))
            write_json(RESULTS_FILE, {"source_url": source_url, "final_url": source_url, "updated_at": int(time.time()), "items": items})
        body = "<p>已提交。请回到 KODI 插件查看最近嗅探结果。</p><p><a href='/'>继续提交</a></p>"
        self.send_html(200, "提交成功", body)


def setting_bool(name, default=False):
    try:
        return ADDON.getSettingBool(name)
    except Exception:
        value = ADDON.getSetting(name)
        if not value:
            return default
        return value.lower() in ("true", "1", "yes")


def setting_int(name, default):
    try:
        return int(ADDON.getSetting(name) or default)
    except ValueError:
        return default


def ensure_profile_dir():
    if not xbmcvfs.exists(PROFILE_DIR):
        xbmcvfs.mkdirs(PROFILE_DIR)


def read_json(path, default):
    fh = None
    try:
        fh = xbmcvfs.File(path, "r")
        raw = fh.read()
        return json.loads(raw) if raw else default
    except Exception:
        return default
    finally:
        if fh:
            fh.close()


def write_json(path, data):
    ensure_profile_dir()
    fh = xbmcvfs.File(path, "w")
    try:
        fh.write(json.dumps(data, ensure_ascii=False, indent=2))
    finally:
        fh.close()


def plugin_url(action, **params):
    query = {"action": action}
    query.update(params)
    return BASE_URL + "?" + urlencode(query)


def add_directory_item(label, action=None, params=None, icon=None, playable=False, target_url=None):
    params = params or {}
    url = target_url if target_url else plugin_url(action, **params)
    item = xbmcgui.ListItem(label=label)
    if icon:
        item.setArt({"thumb": icon, "icon": icon})
    if playable:
        item.setProperty("IsPlayable", "true")
        item.setInfo("video", {"title": label})
    xbmcplugin.addDirectoryItem(HANDLE, url, item, isFolder=not playable)


def get_params():
    if len(sys.argv) < 3 or not sys.argv[2]:
        return {}
    return {key: values[0] for key, values in parse_qs(sys.argv[2].lstrip("?")).items()}


def current_url():
    state = read_json(SERVER_STATE_FILE, {})
    return state.get("target_url") or ADDON.getSetting("target_url")


def save_current_url(url):
    if not url:
        return
    ADDON.setSetting("target_url", url)
    state = read_json(SERVER_STATE_FILE, {})
    state["target_url"] = url
    state["updated_at"] = int(time.time())
    write_json(SERVER_STATE_FILE, state)


def normalize_url(value, page_url):
    if not value:
        return ""
    cleaned = html.unescape(value).replace("\\/", "/").strip()
    cleaned = cleaned.replace("&amp;", "&")
    if cleaned.startswith("//"):
        scheme = urlparse(page_url).scheme or "https"
        cleaned = scheme + ":" + cleaned
    return urljoin(page_url, cleaned)


def quality_from_url(url):
    lowered = url.lower()
    for quality in ("2160", "1440", "1080", "720", "576", "540", "480", "360", "240"):
        if quality in lowered:
            return quality + "p"
    return "未知清晰度"


def media_type(url):
    path = urlparse(url).path.lower()
    if path.endswith(".m3u8"):
        return "M3U8"
    if path.endswith(".mp4"):
        return "MP4"
    if path.endswith(".webm"):
        return "WEBM"
    if path.endswith(".mov"):
        return "MOV"
    return "VIDEO"


def extract_first(pattern, text, flags=re.I | re.S):
    match = re.search(pattern, text or "", flags)
    if not match:
        return ""
    return html.unescape(match.group(1).strip())


def extract_metadata(page_url, body):
    title = extract_first(r"<title[^>]*>(.*?)</title>", body) or "未知视频"
    title = re.sub(r"\s+", " ", title).strip()
    thumb = extract_first(r"<meta[^>]+(?:property|name)=['\"](?:og:image|twitter:image)['\"][^>]+content=['\"]([^'\"]+)", body)
    if not thumb:
        thumb = extract_first(r"<(?:video|source)[^>]+poster=['\"]([^'\"]+)", body)
    if thumb:
        thumb = normalize_url(thumb, page_url)
    return title, thumb


def fetch_url(url, accept="text/html,*/*"):
    timeout = setting_int("request_timeout", 15)
    user_agent = ADDON.getSetting("user_agent") or "Mozilla/5.0"
    headers = {"User-Agent": user_agent, "Accept": accept, "Referer": url}
    diagnostics = {"url": url, "ok": False, "status": None, "content_type": "", "final_url": url, "error": "", "snippet": ""}
    try:
        request = Request(url, headers=headers)
        with urlopen(request, timeout=timeout) as response:
            raw = response.read(2 * 1024 * 1024)
            content_type = response.headers.get("Content-Type", "")
            charset = response.headers.get_content_charset() or "utf-8"
            text = raw.decode(charset, "replace")
            diagnostics.update({"ok": True, "status": response.getcode(), "content_type": content_type, "final_url": response.geturl(), "snippet": text[:1000]})
            return text, diagnostics
    except HTTPError as exc:
        body = exc.read(4096).decode("utf-8", "replace") if exc.fp else ""
        diagnostics.update({"status": exc.code, "error": str(exc), "snippet": body[:1000]})
    except (URLError, OSError, ValueError) as exc:
        diagnostics["error"] = str(exc)
    return "", diagnostics


def parse_m3u8_variants(master_url, playlist, title, thumb):
    results = []
    lines = playlist.splitlines()
    for index, line in enumerate(lines):
        if not line.startswith("#EXT-X-STREAM-INF"):
            continue
        stream_url = ""
        for candidate in lines[index + 1:]:
            candidate = candidate.strip()
            if candidate and not candidate.startswith("#"):
                stream_url = normalize_url(candidate, master_url)
                break
        if not stream_url:
            continue
        resolution = extract_first(r"RESOLUTION=\d+x(\d+)", line, re.I)
        bandwidth = extract_first(r"BANDWIDTH=(\d+)", line, re.I)
        quality = (resolution + "p") if resolution else quality_from_url(stream_url)
        if quality == "未知清晰度" and bandwidth:
            quality = str(round(int(bandwidth) / 1000000, 1)) + "Mbps"
        results.append({"url": stream_url, "label": "%s (%s M3U8)" % (title, quality), "title": title, "quality": quality, "type": "M3U8", "thumb": thumb})
    return results


def extract_media(page_url, body, title, thumb):
    seen = set()
    results = []
    candidates = []
    for regex in (MEDIA_RE, ATTR_MEDIA_RE):
        for match in regex.finditer(body or ""):
            candidates.append(match.group("url"))
    for candidate in candidates:
        url = normalize_url(candidate, page_url)
        if not url or url in seen:
            continue
        seen.add(url)
        kind = media_type(url)
        if kind == "M3U8" and not setting_bool("enable_m3u8", True):
            continue
        if kind == "MP4" and not setting_bool("enable_mp4", True):
            continue
        if kind in ("WEBM", "MOV") and not setting_bool("enable_other_video", True):
            continue
        quality = quality_from_url(url)
        results.append({"url": url, "label": "%s (%s %s)" % (title, quality, kind), "title": title, "quality": quality, "type": kind, "thumb": thumb})
    return results


def expand_m3u8_results(results):
    expanded = []
    for item in results:
        expanded.append(item)
        if item["type"] != "M3U8":
            continue
        playlist, diagnostics = fetch_url(item["url"], accept="application/vnd.apple.mpegurl,*/*")
        if diagnostics.get("ok") and "#EXT-X-STREAM-INF" in playlist:
            expanded.extend(parse_m3u8_variants(item["url"], playlist, item["title"], item.get("thumb")))
    unique = []
    seen = set()
    for item in expanded:
        if item["url"] in seen:
            continue
        seen.add(item["url"])
        unique.append(item)
    return unique


def quality_label_from_format(fmt):
    height = fmt.get("height")
    width = fmt.get("width")
    format_note = fmt.get("format_note") or fmt.get("resolution") or ""
    if height:
        return "%sp" % height
    if format_note:
        return str(format_note)
    if width and height:
        return "%sx%s" % (width, height)
    return "未知清晰度"


def thumb_from_format(fmt, fallback):
    for key in ("thumbnail", "url", "webpage_url"):
        value = fmt.get(key)
        if value:
            return value
    return fallback or ""


def extract_with_ytdlp(url):
    diagnostics = {"url": url, "ok": False, "status": None, "content_type": "yt-dlp", "final_url": url, "error": "", "snippet": ""}
    if not setting_bool("enable_ytdlp", True):
        diagnostics["error"] = "设置已关闭 yt-dlp"
        return [], diagnostics
    spec = importlib.util.find_spec("yt_dlp")
    if not spec:
        diagnostics["error"] = "yt-dlp 未安装，且未在 resources/lib/yt_dlp.zip 找到内置包"
        return [], diagnostics
    try:
        import yt_dlp

        timeout = setting_int("ytdlp_timeout", 8)
        options = {
            "quiet": True,
            "no_warnings": True,
            "skip_download": True,
            "noplaylist": True,
            "extract_flat": False,
            "socket_timeout": timeout,
            "retries": 1,
            "fragment_retries": 1,
            "extractor_retries": 1,
            "file_access_retries": 1,
            "ignore_no_formats_error": True,
            "playlistend": 1,
            "http_headers": {"User-Agent": ADDON.getSetting("user_agent") or "Mozilla/5.0"},
        }
        with yt_dlp.YoutubeDL(options) as ydl:
            info = ydl.extract_info(url, download=False)
        diagnostics["ok"] = True
        diagnostics["final_url"] = info.get("webpage_url") or info.get("original_url") or url
        diagnostics["snippet"] = "yt-dlp: %s | %s" % (getattr(yt_dlp.version, "__version__", "unknown"), info.get("title") or info.get("extractor_key") or "")
        title = info.get("title") or "未知视频"
        thumb = info.get("thumbnail") or info.get("thumbnails", [{}])[-1].get("url") if info.get("thumbnails") else ""
        entries = []
        formats = info.get("formats") or []
        for fmt in formats:
            media_url = fmt.get("url")
            if not media_url:
                continue
            vcodec = (fmt.get("vcodec") or "").lower()
            acodec = (fmt.get("acodec") or "").lower()
            if vcodec == "none" and acodec != "none":
                continue
            label_parts = []
            if fmt.get("format_id"):
                label_parts.append(str(fmt.get("format_id")))
            label_parts.append(quality_label_from_format(fmt))
            if fmt.get("ext"):
                label_parts.append(str(fmt.get("ext")).upper())
            entries.append({
                "url": media_url,
                "label": "%s (%s)" % (title, " ".join(label_parts).strip()),
                "title": title,
                "quality": quality_label_from_format(fmt),
                "type": (fmt.get("ext") or media_type(media_url)).upper(),
                "thumb": thumb_from_format(fmt, thumb),
            })
        if not entries and info.get("url"):
            entries.append({
                "url": info.get("url"),
                "label": "%s (yt-dlp)" % title,
                "title": title,
                "quality": "yt-dlp",
                "type": media_type(info.get("url")),
                "thumb": thumb,
            })
        return entries, diagnostics
    except Exception as exc:
        diagnostics["error"] = str(exc)
        return [], diagnostics


def sniff_video(url):
    results, diagnostics = extract_with_ytdlp(url)
    source = "yt-dlp"
    if not results:
        fallback_reason = diagnostics.get("error") or "yt-dlp 未返回结果"
        body, fallback_diagnostics = fetch_url(url)
        diagnostics = fallback_diagnostics
        if not diagnostics.get("ok"):
            diagnostics["error"] = (fallback_reason + "; " + diagnostics.get("error", "")).strip("; ")
            write_json(DIAGNOSTICS_FILE, diagnostics)
            return []
        page_url = diagnostics.get("final_url") or url
        title, thumb = extract_metadata(page_url, body)
        results = expand_m3u8_results(extract_media(page_url, body, title, thumb))
        source = "custom"
        diagnostics["content_type"] = diagnostics.get("content_type") or "html"
        diagnostics["snippet"] = "回退自自定义嗅探: %s | %s" % (fallback_reason, diagnostics.get("snippet") or title)
    page_url = diagnostics.get("final_url") or url
    payload = {"source_url": url, "final_url": page_url, "updated_at": int(time.time()), "source": source, "items": results}
    write_json(RESULTS_FILE, payload)
    write_json(DIAGNOSTICS_FILE, diagnostics)
    return results


def list_root():
    url = current_url()
    add_directory_item("嗅探当前网页: " + (url or "未设置"), "sniff")
    add_directory_item("输入/修改网页地址", "enter_url")
    add_directory_item("启动手机局域网输入服务", "start_server")
    add_directory_item("打开外部浏览器验证网页", "open_browser")
    add_directory_item("查看最近嗅探结果", "recent")
    add_directory_item("查看网页错误/诊断信息", "diagnostics")
    xbmcplugin.endOfDirectory(HANDLE)


def list_videos(videos):
    if not videos:
        xbmcgui.Dialog().notification("Video Sniffer", "未找到视频地址", xbmcgui.NOTIFICATION_WARNING)
        list_root()
        return
    for video in videos:
        add_directory_item(video["label"], "play", {"url": video["url"], "label": video["label"]}, icon=video.get("thumb"), playable=True)
    xbmcplugin.endOfDirectory(HANDLE)


def enter_url():
    keyboard = xbmc.Keyboard(current_url() or "", "输入视频网页地址")
    keyboard.doModal()
    if keyboard.isConfirmed():
        url = keyboard.getText().strip()
        save_current_url(url)
        xbmcgui.Dialog().notification("Video Sniffer", "已保存网页地址", xbmcgui.NOTIFICATION_INFO)
    list_root()


def play_url(params):
    url = params.get("url", "")
    label = params.get("label", "视频")
    item = xbmcgui.ListItem(label=label, path=url)
    item.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(HANDLE, bool(url), item)


def show_diagnostics():
    diagnostics = read_json(DIAGNOSTICS_FILE, {})
    if not diagnostics:
        xbmcgui.Dialog().ok("Video Sniffer", "暂无诊断信息")
        list_root()
        return
    message = "URL: {url}\n状态: {status}\n类型: {content_type}\n错误: {error}\n\n{snippet}".format(**{
        "url": diagnostics.get("url", ""),
        "status": diagnostics.get("status", ""),
        "content_type": diagnostics.get("content_type", ""),
        "error": diagnostics.get("error", ""),
        "snippet": diagnostics.get("snippet", "")[:800],
    })
    xbmcgui.Dialog().textviewer("网页错误/诊断信息", message)
    list_root()


def show_recent():
    payload = read_json(RESULTS_FILE, {})
    list_videos(payload.get("items", []))


def route():
    params = get_params()
    action = params.get("action", "root")
    if action == "sniff":
        url = current_url()
        if not url:
            xbmcgui.Dialog().notification("Video Sniffer", "请先输入网页地址", xbmcgui.NOTIFICATION_INFO)
            list_root()
        else:
            list_videos(sniff_video(url))
    elif action == "enter_url":
        enter_url()
    elif action == "play":
        play_url(params)
    elif action == "recent":
        show_recent()
    elif action == "diagnostics":
        show_diagnostics()
    elif action == "start_server":
        start_server_action()
    elif action == "open_browser":
        open_browser_action()
    else:
        list_root()


def local_ip_addresses():
    addresses = []
    try:
        hostname = socket.gethostname()
        for item in socket.getaddrinfo(hostname, None, socket.AF_INET):
            ip = item[4][0]
            if ip not in addresses and not ip.startswith("127."):
                addresses.append(ip)
    except OSError:
        pass
    try:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.connect(("8.8.8.8", 80))
        ip = sock.getsockname()[0]
        sock.close()
        if ip not in addresses:
            addresses.insert(0, ip)
    except OSError:
        pass
    return addresses or ["电视盒子IP"]


def start_phone_server():
    global RUNNING_SERVER
    if RUNNING_SERVER:
        return RUNNING_SERVER
    port = setting_int("server_port", 19191)
    server = ThreadingHTTPServer(("0.0.0.0", port), PhoneInputHandler)
    thread = threading.Thread(target=server.serve_forever)
    thread.daemon = True
    thread.start()
    RUNNING_SERVER = server
    return server


def start_server_action():
    global RUNNING_SERVER
    try:
        server = start_phone_server()
        port = server.server_address[1]
        addresses = ["http://%s:%s/" % (ip, port) for ip in local_ip_addresses()]
        xbmcgui.Dialog().ok("手机局域网输入服务", "服务运行中，关闭此窗口后服务会停止。\n\n手机连接同一 Wi-Fi 后访问：\n" + "\n".join(addresses))
        server.shutdown()
        server.server_close()
        RUNNING_SERVER = None
    except OSError as exc:
        xbmcgui.Dialog().ok("手机局域网输入服务", "启动失败：%s\n\n请检查端口是否被占用，或在设置中换一个端口。" % exc)
    list_root()


def open_browser_action():
    url = current_url()
    if not url:
        xbmcgui.Dialog().notification("Video Sniffer", "请先输入网页地址", xbmcgui.NOTIFICATION_INFO)
        list_root()
        return
    try:
        xbmc.executebuiltin("StartAndroidActivity(,android.intent.action.VIEW,,%s)" % quote(url, safe=":/?&=%#"))
        xbmcgui.Dialog().ok("外部浏览器验证", "已尝试打开外部浏览器/WebView。\n\n完成人机验证后，请用手机局域网输入页面提交最终网页地址、页面源码或视频直链。")
    except Exception as exc:
        xbmcgui.Dialog().ok("外部浏览器验证", "无法自动打开浏览器：%s\n\n请手动打开：\n%s" % (exc, url))
    list_root()


if __name__ == "__main__":
    route()
