# Bundled yt-dlp Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Bundle `yt-dlp` inside the Kodi add-on so Kodi 21.5 on Android 9 can use hybrid sniffing without a system-installed `yt-dlp` package.

**Architecture:** Place the pure-Python `yt_dlp` package under `resources/lib`, add that directory to `sys.path` before importing, and keep the current custom sniffer as fallback. Do not add runtime downloads or platform binaries.

**Tech Stack:** Kodi Python 3, bundled pure-Python `yt_dlp`, existing plugin routing and custom sniffing fallback.

---

### Task 1: Vendor yt-dlp

**Files:**
- Create: `resources/lib/yt_dlp/**`

**Step 1: Download the wheel**

Download the latest `yt-dlp` wheel from PyPI or GitHub release assets to a temporary directory.

**Step 2: Extract package**

Extract only `yt_dlp` into `resources/lib/yt_dlp`.

**Step 3: Avoid unnecessary files**

Do not include tests, caches, or dist metadata unless required by import.

### Task 2: Prefer bundled package

**Files:**
- Modify: `default.py`

**Step 1: Add bundled library path**

Insert `resources/lib` at the front of `sys.path` before `extract_with_ytdlp()` imports `yt_dlp`.

**Step 2: Improve diagnostics**

Report whether bundled `yt-dlp` was found and whether import failed.

### Task 3: Verify and package

**Files:**
- Verify: `resources/lib/yt_dlp/__init__.py`
- Verify: `default.py`
- Update: `plugin.video.sniffer.zip`

**Step 1: Verify package exists**

Check that `resources/lib/yt_dlp/__init__.py` exists.

**Step 2: Verify references**

Search `default.py` for `resources/lib` and `yt_dlp` import path handling.

**Step 3: Rebuild zip**

Package as `plugin.video.sniffer.zip` with root folder `plugin.video.sniffer`.
