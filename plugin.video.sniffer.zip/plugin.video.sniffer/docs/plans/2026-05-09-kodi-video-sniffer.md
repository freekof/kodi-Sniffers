# KODI Video Sniffer Implementation Plan

> **For Claude:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task.

**Goal:** Build a Kodi video-sniffer plugin that accepts video page URLs from Kodi settings or LAN phones, opens pages in an external Android browser/WebView when verification is needed, lists detected video streams with thumbnails and quality labels, and plays selected streams in Kodi on Android 9.

**Architecture:** Keep the add-on self-contained in `default.py` with standard Kodi Python APIs and Python standard library where possible. Add a small local HTTP server for LAN URL submission, robust HTML/media parsing, simple m3u8 variant parsing, persistent cache files under the add-on profile, and Kodi directory entries for actions and playback.

**Tech Stack:** Kodi Python 3 add-on API, `urllib.request`, `http.server`, `threading`, `json`, `re`, optional Android external browser invocation via `xbmc.executebuiltin` or Android intent fallback.

---

### Task 1: Add settings and metadata

**Files:**
- Modify: `addon.xml`
- Modify: `resources/settings.xml`

**Step 1: Update settings**

Add settings for server port, user agent, request timeout, last URL, and browser handoff preference.

**Step 2: Update add-on metadata**

Add summary/description/platform metadata so Kodi shows the add-on clearly.

**Step 3: Verify XML syntax**

Run: `python -c "import xml.etree.ElementTree as ET; ET.parse('addon.xml'); ET.parse('resources/settings.xml'); print('xml ok')"`

Expected: `xml ok`

### Task 2: Refactor plugin routing and UI actions

**Files:**
- Modify: `default.py`

**Step 1: Add route parser**

Parse `sys.argv[2]` query parameters with `urllib.parse.parse_qs`.

**Step 2: Add root menu**

Create directory entries for sniff current URL, enter URL, start LAN receiver, open external browser, recent results, and diagnostics.

**Step 3: Add playback route**

Use `xbmcplugin.setResolvedUrl` for playable URLs instead of only adding raw directory items.

**Step 4: Verify import safety**

Run: `python -m py_compile default.py`

Expected: no syntax errors. Kodi modules may be unavailable outside Kodi only if imports are not stubbed; if needed, use syntax-only compile.

### Task 3: Implement media sniffing

**Files:**
- Modify: `default.py`

**Step 1: Replace `requests` and `bs4` dependencies**

Use `urllib.request` and regex parsing so Android Kodi installs do not need external Python packages.

**Step 2: Fetch page with headers and timeout**

Return structured diagnostics: status, content type, final URL, error message, and HTML snippet.

**Step 3: Extract metadata**

Parse title, `og:image`, `twitter:image`, and common poster attributes.

**Step 4: Extract media URLs**

Find absolute and relative URLs for `.m3u8`, `.mp4`, `.webm`, `.mov`, and common JSON-escaped variants.

**Step 5: Parse m3u8 variants**

For master playlists, parse `#EXT-X-STREAM-INF` bandwidth/resolution lines and create separate quality entries.

**Step 6: Cache results**

Write recent URL, results, and diagnostics to JSON files in `special://profile/addon_data/plugin.video.sniffer`.

### Task 4: Implement LAN phone input service

**Files:**
- Modify: `default.py`

**Step 1: Add HTTP server**

Use `http.server.ThreadingHTTPServer` on configurable port, bound to `0.0.0.0`.

**Step 2: Add phone form**

Serve a simple HTML page with fields for webpage URL and direct video URL/page source fallback.

**Step 3: Handle submissions**

Store submitted URL or media URL in the add-on profile cache and show confirmation page.

**Step 4: Show LAN address in Kodi**

Detect local IP candidates and show `http://IP:port/` in a Kodi dialog.

### Task 5: Implement external browser handoff

**Files:**
- Modify: `default.py`

**Step 1: Add browser action**

Open current URL using Kodi `StartAndroidActivity` when available, otherwise show the URL and LAN receiver instructions.

**Step 2: Add verification workflow**

After browser verification, instruct user to submit final URL or detected media URL through the phone form.

**Step 3: Preserve diagnostics**

If fetch fails because of verification, show status/error and offer external browser handoff.

### Task 6: Verify package

**Files:**
- Verify: `default.py`
- Verify: `addon.xml`
- Verify: `resources/settings.xml`

**Step 1: Run syntax checks**

Run: `python -m py_compile default.py`

Expected: no syntax errors.

**Step 2: Run XML checks**

Run: `python -c "import xml.etree.ElementTree as ET; ET.parse('addon.xml'); ET.parse('resources/settings.xml'); print('xml ok')"`

Expected: `xml ok`.

**Step 3: Rebuild zip**

Package folder as `plugin.video.sniffer.zip` preserving add-on root directory.

**Step 4: Manual Kodi test**

Install zip on Android 9 Kodi, open add-on, start LAN receiver, submit a test URL from phone, sniff, choose a stream, and verify Kodi playback starts.
